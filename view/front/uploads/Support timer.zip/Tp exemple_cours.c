int NB;
void main() {
 //config
 
 TRISA = 0;
 TRISB=0;
 INTCON.GIE=1;
 INTCON.T0IE = 1;
 OPTION_REG = 0b00000101;
 TMR0=0;
 NB=61;
 
 //initialement
 PORTA = 0;
 PORTB.RB3=1;
 
 //traitement
 
 while(1){
  PORTA=10;
 }
}

void interrupt(){
  if(INTCON.T0IF == 1){
      INTCON.T0IF = 0;
   NB--;
   if (NB==0){

    PORTB.RB3 =~PORTB.RB3;
    NB=61;
    TMR0=0;
   }

  }


}